
<?php
// Author: SABELO S VILAKATI 
//Email  : mrsabelovilakti@gmail.com
//Phone  :(+268)76871675
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                             // Passing `true` enables exceptions
if (isset($_POST['send'])) {
    try {
                //put sender email addresss                                           
               //******vvvv*********
        $mail->setFrom('   ', 'Mailer');
        $mail->addAddress($_POST['email'], $_POST['name']);     // Add a recipient
        $mail->addReplyTo($_POST['email'], $_POST['name']);
        //Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Here is the subject';
        $mail->Body    = "<h3>".$_POST['msg']."</h3>";;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
    }
}

?>
<form action="" method="POST">
    <div><input type="text" name="name" placeholder="name" ></div>
    <div><input type="email" name="email" placeholder="email" ></div>
    <div><textarea name="msg" placeholder="message"></textarea>  </div>
    <div><input type="submit" name="send" value="Send" ></div>
</form>

